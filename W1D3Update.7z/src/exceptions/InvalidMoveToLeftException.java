package exceptions;

/**
 * Created by sgrecu on 10/22/2018.
 */
public class InvalidMoveToLeftException extends InvalidMoveException {
    public InvalidMoveToLeftException(String message) {
        super(message);
    }
}
