package exceptions;

/**
 * Created by sgrecu on 10/23/2018.
 */
public class InvalidRadiusException extends MovableException {
    public InvalidRadiusException(String message) {
        super(message);
    }
}
