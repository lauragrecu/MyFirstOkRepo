package exceptions;

/**
 * Created by sgrecu on 10/22/2018.
 */
public class PointOutOfPlainException extends OutOfPlainException {
    public PointOutOfPlainException(String message) {
        super(message);
    }
}
