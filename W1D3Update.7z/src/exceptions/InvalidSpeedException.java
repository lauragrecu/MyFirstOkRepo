package exceptions;

/**
 * Created by sgrecu on 10/24/2018.
 */
public class InvalidSpeedException extends MovableException {
    public InvalidSpeedException(String message) {
        super(message);
    }
}
