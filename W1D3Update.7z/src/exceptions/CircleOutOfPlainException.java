package exceptions;

/**
 * Created by sgrecu on 10/22/2018.
 */
public class CircleOutOfPlainException extends OutOfPlainException {
    public CircleOutOfPlainException(String message) {
        super(message);
    }
}
