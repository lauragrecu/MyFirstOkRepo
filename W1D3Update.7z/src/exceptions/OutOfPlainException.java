package exceptions;

/**
 * Created by sgrecu on 10/22/2018.
 */
public class OutOfPlainException extends MovableException {
    public OutOfPlainException(String message) {
        super(message);
    }
}
