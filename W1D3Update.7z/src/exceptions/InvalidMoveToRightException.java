package exceptions;

/**
 * Created by sgrecu on 10/22/2018.
 */
public class InvalidMoveToRightException extends InvalidMoveException {
    public InvalidMoveToRightException(String message) {
        super(message);
    }
}
