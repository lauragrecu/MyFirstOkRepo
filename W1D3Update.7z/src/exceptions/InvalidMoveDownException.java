package exceptions;

/**
 * Created by sgrecu on 10/22/2018.
 */
public class InvalidMoveDownException extends InvalidMoveException {
    public InvalidMoveDownException(String message) {
        super(message);
    }
}
