package exceptions;

/**
 * Created by sgrecu on 10/22/2018.
 */
public class InvalidMoveUpException extends InvalidMoveException {
    public InvalidMoveUpException(String message) {
        super(message);
    }
}
