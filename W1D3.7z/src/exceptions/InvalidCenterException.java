package exceptions;

/**
 * Created by sgrecu on 10/24/2018.
 */
public class InvalidCenterException extends MovableException {
    public InvalidCenterException(String message) {
        super(message);
    }
}
